package java8.features;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;  

public class Lambda4 {

	public static void main(String[] args) {

		List<Employee> empList = new ArrayList<Employee>();
		empList.add(new Employee("Neel", 4857021, 100000.00));
		empList.add(new Employee("Ravi", 4857035, 150000.00));
		empList.add(new Employee("Sweta", 485704, 50000.00));
		empList.add(new Employee("Manish", 485705, 120000.00));
		empList.add(new Employee("Singh", 485706, 200000.00));
		
		empList.sort((e1,e2)->(e1.empId-e2.empId));
		//empList.sort((e1,e2)->(e1.empSalary.compareTo(e2.empSalary)));
		//empList.sort((e1,e2)->(e1.empName.compareToIgnoreCase(e2.empName)));
		
		Collections.sort(empList,(e1,e2)->(e1.empId-e2.empId));
		
		empList.forEach(e->{
			System.out.println(e.empName+"-"+e.empId+"-"+e.empSalary);
		});
		
		List<Double> pricesList =  empList.stream()  
                .filter(e ->e.empSalary>= 200000)   // filtering price  
                .map(es ->es.empSalary)          // fetching price  
                .collect(Collectors.toList());  
		System.out.println(pricesList); 

	}

}
