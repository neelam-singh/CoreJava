package java8.features;

import java.util.ArrayList;

public class Lambda2 {

	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(2000);
		list.add(1705);
		list.add(4000);
		list.add(9000);
		
		//print content
		list.forEach((l)->System.out.println(l));

		//print conditinal
		list.forEach((l)->{
			if(l%2 == 0)
			{
				System.out.println("conditinal"+l);
			}
		});

	}

}
