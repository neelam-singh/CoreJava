package java8.features;

public class StrReverse {

	public static void main(String[] args) {
		String str = "123";
		str = reverse(str);
		System.out.println(str);

	}

	private static String reverse(String str) {
		StringBuilder sb = new StringBuilder();
		
		char[] strArry= str.toCharArray();
		for (int i = strArry.length-1; i >= 0; i--) {
			sb.append(strArry[i]);
		}
		
		return sb.toString();
	}

}
