package java8.features;

public class Palindrome {

	public static void main(String[] args) {
		String str1 = "abcdcba";
		
		StringBuffer strBuffer = new StringBuffer(str1);
		System.out.println("strBuffer :"+strBuffer);
		
		if(strBuffer.reverse().toString().equals(str1))
		{
			System.out.println("str1 is palindrome");
		}

	}

}
