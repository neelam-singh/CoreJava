package java8.features;

public class SwapNumbrs {

	public static void main(String[] args) {
		int a = 10;
		int b = 20;
		swapNumbers(a, b);
		System.out.println(a+":"+b);
		b = b+a;
		a = b-a;
		b = b-a;
		System.out.println(a+":"+b);
	}

	private static void swapNumbers(int a, int b) {
		b = b+a;
		a = b-a;
		b = b-a;
	}

}
