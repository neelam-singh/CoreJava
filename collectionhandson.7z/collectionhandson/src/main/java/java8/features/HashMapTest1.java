package java8.features;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;

public class HashMapTest1 {

	public static void main(String[] args) {

		Map<String,String> testMap = new HashMap<>();
		testMap.put("1", "test1");
		testMap.put(null, null);
		testMap.put("5", null);
		testMap.put("2", "test2");
		testMap.put("3", "test3");
		testMap.put("4", "test4");
		
		/*
		 * Iterator it = testMap.entrySet().iterator();
		 * 
		 * while(it.hasNext()) { Map.Entry entry = (Map.Entry) it.next();
		 * System.out.println(entry.getKey()+":"+entry.getValue()); }
		 */
		
		testMap.forEach((k,v)->
		{
			System.out.println(k+":"+v);
		});
		
		List<String> listOP = testMap.entrySet().stream()
					.filter(e -> e.getValue().startsWith("test2"))
				    .map(Map.Entry::getKey)
				    .collect(Collector.toList());
		
		listOP.forEach(s->{
			System.out.println("key in List:"+s);
		});
		
		

	}
	
	//list to map
	//map to list
	//sort list
	//sort map
	//iterate
	//foreach loop
	
	//https://www.journaldev.com/370/java-programming-interview-questions

}
