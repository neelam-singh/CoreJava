package java8.features;

import java.util.ArrayList;
import java.util.List;

public class OnlyOdd {

	public static void main(String[] args) {
		List<Integer> listOdd = new ArrayList<>();
		List<Integer> listInt = new ArrayList<>();
		listInt.add(1);
		listInt.add(11);
		listInt.add(12);
		listInt.add(13);
		listInt.add(14);
		listInt.add(15);
		listInt.add(16);
		listInt.add(17);
		listInt.add(18);
		listInt.add(19);
		listInt.add(20);
		
		listInt.forEach(e->{
			if(e%2 != 0)
			{
				listOdd.add(e);
			}
		});
		
		listOdd.forEach(i->{
			System.out.println(i);
		});

	}

}
