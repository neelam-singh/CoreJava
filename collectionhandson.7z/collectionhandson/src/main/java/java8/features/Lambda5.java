package java8.features;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;

public class Lambda5 {

	public static void main(String[] args) {
		
		Map<Integer, Double> sortedrvuMap = new HashMap<>();
		
		List<ClaimItem> itemsList = new ArrayList<>();
		
		itemsList.add(new ClaimItem(0, 2000.00));
		itemsList.add(new ClaimItem(1, 5000.00));
		itemsList.add(new ClaimItem(2, 1000.00));
		itemsList.add(new ClaimItem(3, 200.00));
		itemsList.add(new ClaimItem(4, 8000.00));
		
		itemsList.sort((item1, item2)->item2.rvuValue.compareTo(item1.rvuValue));
		
		itemsList.forEach(item->{
			System.out.println(item.itemNumber+":"+item.rvuValue);
		});
		
		itemsList.forEach(pList->{
			sortedrvuMap.put(pList.itemNumber, pList.rvuValue);
	        });
		
		/*
		 * sortedrvuMap = itemsList.stream().collect(
		 * Collectors.toMap(ClaimItem::getItemNumber, ClaimItem::getRvuValue));
		 */
		
		sortedrvuMap.forEach((k,v)->{
			System.out.println(k+":"+v);
		});
		
		
	}

}
