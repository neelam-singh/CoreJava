package java8.features;

public class ClaimItem {
	
	int itemNumber;
	Double rvuValue;
	public ClaimItem(int itemNumber, Double rvuValue) {
		super();
		this.itemNumber = itemNumber;
		this.rvuValue = rvuValue;
	}
	public int getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(int itemNumber) {
		this.itemNumber = itemNumber;
	}
	public Double getRvuValue() {
		return rvuValue;
	}
	public void setRvuValue(Double rvuValue) {
		this.rvuValue = rvuValue;
	}
	
	
	
	
	

}
