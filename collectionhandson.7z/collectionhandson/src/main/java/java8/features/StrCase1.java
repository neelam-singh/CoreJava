package java8.features;

public class StrCase1 {

	public static void main(String[] args) {
		String str = "Time";
		boolean vowelPresent = false;
		vowelPresent = chkStr(str);

	}

	private static boolean chkStr(String str) {
		if(str.toLowerCase().matches(".*[aeiou].*"))
		return false;
		else
			return false;
	}
	

}
