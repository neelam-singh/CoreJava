package java8.features;

interface Calculation
{
	 int add(int a, int b);
	 
}
public class Lambda1 {

	public static void main(String[] args) {
		
		//()->{ functional interface implementation body }
		Calculation calc = (int a, int b)->{
			return a+b;
		};
		System.out.println(calc.add(5, 7));
		
		Calculation calc2 = (int a, int b)->(a+b);
		System.out.println(calc2.add(7, 7));

	}
	
	

}
 