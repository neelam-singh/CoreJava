package java8.features;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ArraySort {

	public static void main(String[] args) {
		int[] intArray = {20,31,22,10,11};
		Arrays.sort(intArray);
		System.out.println(Arrays.toString(intArray));
		
		Integer[] arrOfObjects = new Integer[intArray.length];
		for (int i = 0; i < intArray.length; i++) {
			arrOfObjects[i] = new Integer(intArray[i]);
		}
		Arrays.sort(arrOfObjects, Collections.reverseOrder());
		System.out.println(Arrays.toString(arrOfObjects));
		
		for (int i = 0; i < arrOfObjects.length; i++) {
			intArray[i] = arrOfObjects[i].intValue();
		}
		
		System.out.println(Arrays.toString(intArray));
		
		List<Integer> intObjects = new ArrayList<>();
		intObjects.add(20);
		intObjects.add(31);
		intObjects.add(22);
		intObjects.add(10);
		intObjects.add(11);
		intObjects.add(56);
		
		intObjects.sort((i2,i1)->i2.compareTo(i1));
		intObjects.forEach(i->{
			System.out.println(i);
		});
		
		intObjects.sort(Collections.reverseOrder((i2,i1)->i2.compareTo(i1)));
		
		Collections.sort(intObjects, Collections.reverseOrder());
		intObjects.forEach(i->{
			System.out.println("**"+i);
		});

	}

}
