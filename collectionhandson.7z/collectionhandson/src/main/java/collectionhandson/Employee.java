package collectionhandson;

public class Employee {
	
	String name;
	String department;
	
	
	public Employee(String name, String department) {
		super();
		this.name = name;
		this.department = department;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
	
	
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	public static void main(String args[])
	{
		Employee e1 = new Employee("neel", "Testing");
		Employee e2 = new Employee("kumari", "Dev");
		Employee e3 = new Employee("neel", "Testing");
		
		e2 = e3;
		
		System.out.println(e1.hashCode() == e2.hashCode());
		System.out.println(e1.equals(e2));
		System.out.println(e1.equals(e3));
		System.out.println(e2.equals(e3));
		System.out.println(e3.hashCode() == e2.hashCode());
	}

}
