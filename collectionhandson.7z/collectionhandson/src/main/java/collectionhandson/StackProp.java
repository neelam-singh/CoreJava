package collectionhandson;

import java.util.Iterator;
import java.util.Stack;

public class StackProp {

	public static void main(String[] args) {
				Stack<String> stack = new Stack<String>();  
				stack.push("Ayush");  
				stack.push("Garvit");  
				stack.push("Amit");  
				stack.push("Ashish");  
				stack.push("Garima");  
				System.out.println("stack.peek(): "+stack.peek());
				System.out.println("stack.pop(): "+stack.pop());
				System.out.println("stack.firstElement() " +stack.firstElement());
				System.out.println("stack.lastElement() " +stack.lastElement());
				Iterator<String> itr=stack.iterator();  
				while(itr.hasNext()){  
				System.out.println(itr.next());  
			}  
		} 

}
