package coding.challenge;

public class ReverseInteger {

	public static void main(String[] args) {
		
		int reverse = 0 ;
		int input = 54321;
		
		while(input!= 0)
		{
			reverse = reverse *10 + input%10;//0+1=1
			input = input/10;//5432
		}
		System.out.println(reverse);
	}

}
