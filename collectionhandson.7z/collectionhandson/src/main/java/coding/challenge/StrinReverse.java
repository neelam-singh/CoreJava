package coding.challenge;

public class StrinReverse {

	public static void main(String[] args) {
		String inputStr = "Hello";
		
		String reverseStr = getReverse(inputStr);
		System.out.println(reverseStr);
		
		String reverseStr2 = getReverse2(inputStr);
		System.out.println(reverseStr2);

	}

	private static String getReverse2(String inputStr) {
		StringBuilder builder = new StringBuilder();
		for (int i = inputStr.length()-1; i >= 0; i--) {
			builder.append(inputStr.charAt(i));
		}
		return builder.toString();
	}

	private static String getReverse(String inputStr) {
		StringBuilder builder = new StringBuilder(inputStr);
		return builder.reverse().toString();
	}

}
