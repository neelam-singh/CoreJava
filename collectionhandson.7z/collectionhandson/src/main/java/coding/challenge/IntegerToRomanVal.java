package coding.challenge;

public class IntegerToRomanVal {

	public static void main(String[] args) {

		int input =345;
		String[] units = {"", "one","two","three","four","five","six","seven","eight","nine"};
		String[] tens = {"","ten","twenty","thirty","fourty","fifty","sixty","seventy","eighty","ninety"};
		String[] hundreds = {"","one hundread","two hundred","three hundred","four hundred","five hundred","six hundred",
				"seven hundred","eight hundred","nine hundred"};
		//String[] thousands = {};
		
		String output = hundreds[input/100]
				+tens[(input/10)%10]
				+units[input%10];
				
		System.out.println(output);
				
		/*
		 * 345/100=3=hundred[] 345/10=34%10=4=tens[] 345%10=5units[]
		 */

	}

}
