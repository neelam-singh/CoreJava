package coding.challenge;

public class ShortestSubStr3 {

	public static void main(String[] args) {
		String S = "geeksforgeeks";
		String SubStr = "for";

		int subLen = SubStr.length();
		int originalLen = S.length();

		boolean IsSubStr = getSubSequ(S, SubStr, subLen, originalLen);
		System.out.println("IsSubStr ? : " + IsSubStr);

		//boolean isTruw = isSubSequence(S, SubStr, subLen, originalLen);

	}

	//second string is substring of first
	private static boolean getSubSequ(String s, String subStr, int subLen, int originalLen) 
	{
		String subString = s.substring(s.indexOf('f'), s.indexOf('r')+1);
		
		if(subString.equals(subStr))
		return true;
		else
			return false;
		
	}

	
		static boolean isSubSequence(String str1, String str2, int m, int n)
		{ //Base Cases
			if (m == 0) return true; if (n == 0) return false;
	  
	  // If last characters of two strings are matching 
			if (str1.charAt(m - 1) == str2.charAt(n - 1)) 
				return isSubSequence(str1, str2, m - 1, n - 1);
	  
	  // If last characters are not matching 
			return isSubSequence(str1, str2, m, n- 1); }
	 

}
