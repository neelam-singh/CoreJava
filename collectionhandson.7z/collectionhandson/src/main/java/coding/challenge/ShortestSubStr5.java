package coding.challenge;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class ShortestSubStr5 {

	public static void main(String[] args) {
		String S = "geeksforgeeks";


		Set<String> set = getSubSequ(S);

		set.forEach(s1->{
				System.out.print(s1);
		});
	}

	//remove duplicate occurred character
	private static Set<String> getSubSequ(String s) 
	{
		Set<String> set = new HashSet<>();
		for (int i = 0; i < s.length(); i++) {
			set.add(s.charAt(i)+"");
		}
		return set;
	}

	
		static boolean isSubSequence(String str1, String str2, int m, int n)
		{ //Base Cases
			if (m == 0) return true; if (n == 0) return false;
	  
	  // If last characters of two strings are matching 
			if (str1.charAt(m - 1) == str2.charAt(n - 1)) 
				return isSubSequence(str1, str2, m - 1, n - 1);
	  
	  // If last characters are not matching 
			return isSubSequence(str1, str2, m, n- 1); }
	 

}
