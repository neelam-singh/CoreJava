package coding.challenge;

public class WordsToInt {

	public static void main(String[] args) {
		String input = "three hundred fourty five";
		
		//3+3*100+40+5

	}

}
