package coding.challenge;

public class ShortestSubStr {

	public static void main(String[] args) {
		String S = "ABCDE DIV FGHIJKLMNO AGHJ PQRSTUVWXYZO";
		String SubStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

		int subLen = SubStr.length();
		int originalLen = S.length();

		int subSeqStrLength = getSubSequ(S, SubStr, subLen, originalLen);
		System.out.println("subsequence length: " + subSeqStrLength);

		//boolean isTruw = isSubSequence(S, SubStr, subLen, originalLen);

	}

	//subsequence length
	private static int getSubSequ(String s, String subStr, int subLen, int originalLen) {
		StringBuilder sb = new StringBuilder();
		boolean foundFirstOccurence = false;

		while(subLen > 0)
		{
				if(subStr.charAt(subLen-1) == s.charAt(originalLen-1))
				{
					foundFirstOccurence = true;
					sb.append(s.charAt(originalLen-1));
					subLen--;
					originalLen--;
				}
				else
				{
					if(foundFirstOccurence)
					{
						sb.append(s.charAt(originalLen-1));
					}
					originalLen--;
				}
			}
		System.out.println(sb.reverse().toString());	
		return sb.toString().length();
	}

	
		static boolean isSubSequence(String str1, String str2, int m, int n)
		{ //Base Cases
			if (m == 0) return true; if (n == 0) return false;
	  
	  // If last characters of two strings are matching 
			if (str1.charAt(m - 1) == str2.charAt(n - 1)) 
				return isSubSequence(str1, str2, m - 1, n - 1);
	  
	  // If last characters are not matching 
			return isSubSequence(str1, str2, m, n- 1); }
	 

}
