package coding.challenge;

import java.util.Arrays;

public class ReverseArray {

	public static void main(String[] args) {
		int[] arr = new int[] {5,1,5,3};//8,3,5,1,5
		
		int mid = arr.length/2;
		for(int i=0; i<mid; i++)
		{
			int tmp = arr[i];
			arr[i] = arr[arr.length-i-1];
			arr[arr.length-i-1] = tmp;
			
		}
		
		System.out.println(Arrays.toString(arr));

	}

}
