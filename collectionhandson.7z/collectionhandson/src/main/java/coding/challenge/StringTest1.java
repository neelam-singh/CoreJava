package coding.challenge;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class StringTest1 {

	public static void main(String[] args) {
		String str = "NeElam aAsSaa ^#&!";
		char[] arr1 = str.toCharArray();
		char visited = '0'; 
		int count = 0;
		
		int[] arr = new int[arr1.length];
		for (int i = 0; i < arr1.length; i++) {
			count = 1;
			for (int j = i+1; j < arr.length; j++) {
				if(Character.toLowerCase(arr1[i]) == Character.toLowerCase(arr1[j]))
				{
					System.out.println(arr1[i]);
				}
				
			}
			
			arr[i] = count;
			
		}
		
		//System.out.println(Arrays.toString(arr));

	}

}
