package coding.challenge;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.stream.Collectors;

public class ShortestSubStr4 {

	public static void main(String[] args) {
		String S = "geeksforgeeks";


		Map<Character, Integer> maxOccrStr = getSubSequ(S);

		maxOccrStr.forEach((k,v)->{
			System.out.println(k+":"+v);
		});
		
		System.out.println("sorted map");
		
		maxOccrStr = maxOccrStr.entrySet().stream()
		.sorted(Map.Entry.comparingByValue())
		.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

		maxOccrStr.forEach((k,v)->{
			System.out.println(k+":"+v);
		});

	}

	//maximum occured character and count
	private static Map<Character, Integer> getSubSequ(String s) 
	{
		Map<Character, Integer> map = new HashMap<>();
		for (int i = 0; i < s.length(); i++) {
			if(map.containsKey(s.charAt(i)))
			{
				map.put(s.charAt(i), map.get(s.charAt(i))+1);
			}
			else
			{
				map.put(s.charAt(i), 1);
			}
			
		}
		
		
		return map;
	}

	
		static boolean isSubSequence(String str1, String str2, int m, int n)
		{ //Base Cases
			if (m == 0) return true; if (n == 0) return false;
	  
	  // If last characters of two strings are matching 
			if (str1.charAt(m - 1) == str2.charAt(n - 1)) 
				return isSubSequence(str1, str2, m - 1, n - 1);
	  
	  // If last characters are not matching 
			return isSubSequence(str1, str2, m, n- 1); }
	 

}
