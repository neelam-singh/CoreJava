package coding.challenge;

public class StackClass {
	int[] array;
	int size = 10;
	int top = -1;
	 

	public StackClass() {
		array = new int[size];
	}

	public void push(int item)
	{
		array[++top] = item;
	}
	
	public int pop()
	{
		int i = array[top--];
		return i;
	}
	
	public int peek()
	{
		return top;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
        sb.append('[');
        for(int i = 0; i < size ;i++) {
            sb.append(array[i]+",");
			/*
			 * if(i < size-1){ sb.append(","); }
			 */
        }
        sb.append(']');
        return sb.toString();
	}
	
	
}
