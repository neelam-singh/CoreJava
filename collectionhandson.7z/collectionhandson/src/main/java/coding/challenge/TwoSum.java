package coding.challenge;

import java.util.HashMap;
import java.util.Map;

public class TwoSum {

	public static void main(String[] args) {
		int[] intArray = new int[] {2,4,5,3,7};
		int target = 7;
		int [] result = getSumTarget(intArray, target);
		System.out.println(result[0]+","+result[1]);
	}
	
	public static int[] getSumTarget(int[] intarray, int target)
	{
		Map<Integer, Integer> visitedMap = new HashMap();
		for(int i=0; i< intarray.length;i++)
		{
			int diff = target - intarray[i];
			if(visitedMap.containsKey(diff))
			{
				return new int[] {i, visitedMap.get(diff)};
			}
			else
			{
				visitedMap.put(intarray[i], i);
			}
			
		}
		return  new int[] {-1, -1};
		
	}

}
