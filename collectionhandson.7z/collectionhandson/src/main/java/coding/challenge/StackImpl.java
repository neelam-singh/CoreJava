package coding.challenge;

import java.util.Arrays;

public class StackImpl {

	public static void main(String[] args) {
		StackClass obj = new StackClass();
		obj.push(10);
		obj.push(20);
		obj.push(30);
		obj.push(40);
		obj.push(50);

		System.out.println(obj.toString());
	}

}
