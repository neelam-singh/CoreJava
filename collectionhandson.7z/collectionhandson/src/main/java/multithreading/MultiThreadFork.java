package multithreading;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

public class MultiThreadFork extends RecursiveAction
{
	ForkJoinPool pool = new ForkJoinPool(2);
	
	//pool.invoke(task)
	//task.fork
	//task.join

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void compute() {
		// TODO Auto-generated method stub
		
	}

}
