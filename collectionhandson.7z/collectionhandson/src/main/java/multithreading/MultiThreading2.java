package multithreading;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

public class MultiThreading2 
{

	public static void main(String[] args) {
		ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(2);
		Future<Integer> future = executor.submit(new Task(4));
		try {
			System.out.println(future.get());
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	static class Task implements Callable<Integer>
	{
		int n;
		Task(int n)
		{
			this.n = n;
		}
        
		@Override
		public Integer call() throws Exception {
			if(n%2 == 0)
			{
				return n;
			}
			return 0;
		}
		
	}

}
