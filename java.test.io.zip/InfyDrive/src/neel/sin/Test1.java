package neel.sin;

public class Test1 {

	public static void main(String[] args) {
		//palindrome number
		String firstStr = "12321"; //12421//5 digit//odd
		String secStr = "121";//131//1//odd
		String secStr1 = "124421";//125521//6 digit//even
		
		String outputStr = getNextPaliNum(secStr1);
		System.out.println("next highest palindrome: "+outputStr);
		
	}

	private static String getNextPaliNum(String firstStr) 
	{//12421
		
		StringBuilder sb = new StringBuilder(firstStr);
		int mid = firstStr.length()/2;
		if(firstStr.length()%2 == 0)
		{
			int mid1 = Integer.parseInt(Character.toString(firstStr.charAt(mid-1))) +1 ;
			int mid2 = Integer.parseInt(Character.toString(firstStr.charAt(mid))) +1 ;
			
			sb.setCharAt(mid-1, Character.valueOf((char) mid1));
			sb.setCharAt(mid, Character.valueOf((char) mid2));
			return sb.toString();
		}
		
		
		return null;
	}

}
