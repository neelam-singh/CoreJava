package neelam.singh;

public class ClassA {
	ClassA(){
		System.out.println("A");
	}

}
