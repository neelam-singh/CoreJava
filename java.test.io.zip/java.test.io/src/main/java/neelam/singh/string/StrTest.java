package neelam.singh.string;

public class StrTest {

	public static void main(String[] args) {
		String st1 = new String("Neelam");
		String st2 = new String("neelam");
		
		System.out.println(st1 == st2);
		System.out.println(st1 = st2);

		
		String st3 = "Neelam";
		String st4 = "neelam";
		System.out.println(st3 == st4);
		System.out.println(st3 = st4);
		
		
		String s1 = "abc";
		StringBuffer s2 = new StringBuffer(s1);
		System.out.println(s1.equals(s2));
		
	}

}
