package neelam.singh.collection;

import java.util.ArrayList;
import java.util.List;

public class PhoneDigits {

	public static void main(String[] args) {
		String[] phoneStrArray = new String[]{"abc"};
		
		List<String> list = new ArrayList<>();
		
		//key pressed= 23
		//2->def
		//3->ghi
		
		//dg eg fg
		//dh eh fh
		//di ei fi

	}

}
