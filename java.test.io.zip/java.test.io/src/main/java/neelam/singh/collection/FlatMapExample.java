package neelam.singh.collection;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FlatMapExample {

	public static void main(String[] args) throws IOException {
		// flat map to process collections/streams more than one level
		
				//list of list to list and iterate over
				List<List<String>> listOfList = new ArrayList<>();
				List<String> list1 = new ArrayList<>();
				list1.add("d");
				list1.add("d1");
				list1.add("a");
				list1.add("g");
				List<String> list2 = new ArrayList<>();
				list2.add("u");
				list2.add("t");
				list2.add("89");
				list2.add("gg");
				
				listOfList.add(list1);
				listOfList.add(list2);
				
				List<String> finalList= listOfList.stream()
										.flatMap(List->List.stream())
										.collect(Collectors.toList());
				
				finalList.forEach(s->{
					System.out.println(s);
				});
				
				System.out.println("**********************");
				////////////////////////////////////////////////////////////////
				
				Developer o1 = new Developer();
		        o1.setName("mkyong");
		        o1.addBook("Java 8 in Action");
		        o1.addBook("Spring Boot in Action");
		        o1.addBook("Effective Java (3rd Edition)");

		        Developer o2 = new Developer();
		        o2.setName("zilap");
		        o2.addBook("Learning Python, 5th Edition");
		        o2.addBook("Effective Java (3nd Edition)");

		        List<Developer> devList = new ArrayList<>();
		        devList.add(o1);
		        devList.add(o2);
		        
				Set<String> bookSet =  devList.stream()
				 .flatMap(dev-> dev.getBook().stream())
				 .collect(Collectors.toSet()); 
				
				bookSet.forEach(s->{
					System.out.println(s);
				});
				
				System.out.println("**********************");
				Set<String> bookSet2 =  devList.stream()
						 .flatMap(dev2-> dev2.getBook().stream())
						 .filter(dev2-> !dev2.contains("Python"))
						 .collect(Collectors.toSet()); 
						
						bookSet2.forEach(s2->{
							System.out.println(s2);
						});
						
				System.out.println("**********************");
				
				LineItem item1 = new LineItem(1, "apple", 1, new BigDecimal("1.20"), new BigDecimal("1.20"));
		        LineItem item2 = new LineItem(2, "orange", 2, new BigDecimal(".50"), new BigDecimal("1.00"));
		        Order order1 = new Order(1, "A0000001", Arrays.asList(item1, item2), new BigDecimal("2.20"));

		        LineItem item3 = new LineItem(3, "monitor BenQ", 5, new BigDecimal("99.00"), new BigDecimal("495.00"));
		        LineItem item4 = new LineItem(4, "monitor LG", 10, new BigDecimal("120.00"), new BigDecimal("1200.00"));
		        Order order2 = new Order(2, "A0000002", Arrays.asList(item3, item4), new BigDecimal("1695.00"));

		        LineItem item5 = new LineItem(5, "One Plus 8T", 3, new BigDecimal("499.00"), new BigDecimal("1497.00"));
		        Order order3 = new Order(3, "A0000003", Arrays.asList(item5), new BigDecimal("1497.00"));

		        
		        List<Order> orderList = Arrays.asList(order1, order2, order3);
		        
		        //sum of linetotal
		        
		        BigDecimal sumLineTotal = orderList.stream()
		        .flatMap(order->order.getLineItems().stream())
		        .map(item-> item.getTotal())
		        .reduce(BigDecimal.ZERO, BigDecimal::add);
		        
		        //sum of ordertotal
		        
		        BigDecimal sumOrderTotal = orderList.stream()
		        .map(ordertotal-> ordertotal.getTotal())
		        .reduce(BigDecimal.ZERO, BigDecimal::add);
		        
		        System.out.println(sumLineTotal+":"+sumOrderTotal);
		        
		        BigDecimal sumOrderMax = orderList.stream()
				        .map(ordertotalmax-> ordertotalmax.getTotal())
				        .reduce(BigDecimal.ZERO, BigDecimal::max);
		        
		        System.out.println(sumOrderMax);
		        
		        ///////////////////////////////////////////////////////////////////////////////
		        
		        //spilit line by spaces
		       Path path = Paths.get("C:\\test\\test.txt");
		       Stream<String> Lines= Files.lines(path, StandardCharsets.UTF_8);
		       //Stream<String> words = Lines.flatMap(line->Stream.of(line.split(" +")));
		       Stream<String> words = Lines.flatMap(line -> Stream.of(line.split(" +")));
		       
		       /////////////////////////////////////////////////////////////////////////////
		       
		       //group by
	}

}
