package neelam.singh.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import neelam.singh.Employee;

public class Test1 {

	public static void main(String[] args) {
		//Array sorting with premitives type, asc/desc
		int[] intArray = {12,45,67,1,22,0,5,16};
		
		//asc order
		Arrays.sort(intArray);
		
		System.out.println(Arrays.toString(intArray));
		
		//desc order
		Integer[] intWrapperArray = new Integer[intArray.length];
		for (int i = 0;i<intArray.length; i++) {
			intWrapperArray[i] = new Integer(intArray[i]);
		}
		
		Arrays.sort(intWrapperArray, Collections.reverseOrder());
		
		System.out.println(Arrays.toString(intWrapperArray));
		
		//Array sorting with Wrapper type
		
		String[] strWrapper = new String[] {"test", "apple", "match", "ball"};
		
		Arrays.sort(strWrapper);
		System.out.println(Arrays.toString(strWrapper));
		
		Arrays.sort(strWrapper, Collections.reverseOrder());
		System.out.println(Arrays.toString(strWrapper));
		
		//List sorting with wrapper type
		
		List<String> strList = new ArrayList<>();
		strList.add("d");
		strList.add("d1");
		strList.add("a");
		strList.add("g");
		strList.add("i");
		strList.add("o");
		strList.add("c");
		
		Collections.sort(strList);
		
		strList.forEach(s->{
			System.out.println(s);
		});
		
		Iterator<String> itr = strList.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		Collections.sort(strList, Collections.reverseOrder());
		
		strList.forEach(s->{
			System.out.println(s);
		});
		
		//get List from List of List
		
		List<List<String>> parentList = new ArrayList<List<String>>();
		
		List<String> strList2 = new ArrayList<>();
		strList2.add("y");
		strList2.add("i1");
		strList2.add("a");
		strList2.add("g0");
		strList2.add("p");
		strList2.add("r");
		strList2.add("t");
		
		parentList = Arrays.asList(strList, strList2);
		
		List<String> listResult = parentList.stream()
											.flatMap(list->list.stream())
											.collect(Collectors.toList());
		
		System.out.println("listResult"+listResult);
		
		
		
		//list sorting with object
		
		List<Employee> empList = new ArrayList<>();
		empList.add(new Employee(1, "Ravi", 150000.00));
		empList.add(new Employee(2, "Neelam", 200000.00));
		empList.add(new Employee(3, "Sweta", 50000.00));
		empList.add(new Employee(4, "Singh", 40000.00));
		empList.add(new Employee(5, "Manish", 70000.00));
		empList.add(new Employee(6, "Ranjan", 400000.00));
		
		empList.sort((e1,e2)->e1.getEmpName().compareTo(e2.getEmpName()));
		
		empList.forEach(empList1->{
			System.out.println(empList1.getEmpID()+":"+empList1.getEmpName()+":"+empList1.getEmpSal());
		});
		
		empList.sort(Collections.reverseOrder((e1,e2)->e1.getEmpName().compareTo(e2.getEmpName())));
		System.out.println("reverse order*****");
		empList.forEach(empList1->{
			System.out.println(empList1.getEmpID()+":"+empList1.getEmpName()+":"+empList1.getEmpSal());
		});
		
		
		//get list emp having salary above 100000
		
		empList = empList.stream()
				.filter(e->e.getEmpSal() >= 100000.00)
				.collect(Collectors.toList());
		System.out.println("get emp only e.getEmpSal() >= 100000.00****");
		empList.forEach(empList1->{
			System.out.println(empList1.getEmpID()+":"+empList1.getEmpName()+":"+empList1.getEmpSal());
		});
		
		List<Double> empSalary = empList.stream()
				.filter(e->e.getEmpSal() >= 100000.00)
				.map(e1->e1.getEmpSal())
				.collect(Collectors.toList());
		System.out.println("get only salary deatils e.getEmpSal() >= 100000.00****");
		empSalary.forEach(empSalary1->{
			System.out.println(empSalary1);
		});
		
		//HashMap sorting with premitives
		
		Map<String,String> mapTest = new HashMap<>();
		mapTest.put("1", "65000");
		mapTest.put("2", "55000");
		mapTest.put("3", "75000");
		mapTest.put("4", "60000");
		mapTest.put("5", "45000");
		mapTest.put("6", "35000");
		
		//by key
		List<String> list12 = new ArrayList<>(mapTest.keySet());
		Collections.sort(list12);
		
		//by value
		List<String> list13 = new ArrayList<>(mapTest.values());
		Collections.sort(list13);
		//asc
		mapTest = mapTest.entrySet().stream()
		.sorted(Map.Entry.comparingByKey())
		.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		
		Iterator it = mapTest.entrySet().iterator();
		while(it.hasNext())
		{
			Map.Entry entry = (Entry) it.next();
			System.out.println(entry.getKey()+":"+entry.getValue());
		}
		
		mapTest.forEach((k,v)->{
			System.out.println(k+":"+v);
		});
		
		mapTest.entrySet().stream()
		.sorted(Map.Entry.comparingByValue())
		.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		
		//desc
		Map<String, String> reverseSortedMap = new TreeMap<String, String>(Collections.reverseOrder());
		reverseSortedMap.putAll(mapTest);
				
		reverseSortedMap.forEach((k,v)->{
					System.out.println(k+":"+v);
				});
		
		//custom object map sort by value
		
		Map<Integer,Employee> mapEmp = new HashMap<>();
		mapEmp.put(1, new Employee(1, "Ravi", 150000.00));
		mapEmp.put(1, new Employee(1, "Neel", 250000.00));
		mapEmp.put(1, new Employee(1, "Sweta", 50000.00));
		mapEmp.put(1, new Employee(1, "Singh", 60000.00));
		mapEmp.put(1, new Employee(1, "Nisha", 100000.00));
		
		Comparator<Employee> byname = (e1,e2)->e1.getEmpName().compareTo(e2.getEmpName());
		Comparator<Employee> bynameRev = Collections.reverseOrder((e1,e2)->e1.getEmpName().compareTo(e2.getEmpName()));
		
		mapEmp.entrySet().stream()
		.sorted(Map.Entry.comparingByValue(bynameRev))
		.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		
		
		mapEmp = mapEmp.entrySet().stream()
				.sorted(Map.Entry.<Integer, Employee>comparingByValue(byname))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
		mapEmp.forEach((k,v)->{
			System.out.println(k+":"+v);
		});
		 
	}

}
