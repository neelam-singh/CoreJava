package neelam.singh;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

public class INTARRAY {

	public static void main(String[] args) {
		int[] intArray = {50,40,30,20,5,10};
		
		//asc
		//Arrays.sort(intArray);
		//System.out.println(Arrays.toString(intArray));
		
		sortedArray(intArray);

	}

	private static void sortedArray(int[] intArray) {
		
		//n1 = 50 40
		//n2 = 40 50
		//40,50,...
		//30,40,50,....
		//20,30,40,50...
		//5,20,30,40,50...
		//5,10,20,40,50
		
		//asc order
		for (int i = 0; i < intArray.length; i++) {
			
			for (int j = i+1; j < intArray.length; j++) {
				if(intArray[i] > intArray[j])
				{
					int n1 = intArray[i];
					intArray[i] = intArray[j];
					intArray[j] = n1;
				}
			}
			
		}
		
		System.out.println(Arrays.toString(intArray));
		System.out.println(intArray[intArray.length-1]);
		
		String[] strArrayStrings = new String[intArray.length];
		for (int i = 0; i < intArray.length; i++) {
			strArrayStrings[i] = ""+intArray[i];
		}
		System.out.println("strArrayStrings"+Arrays.toString(strArrayStrings));
		
		char[] charArray = new char[intArray.length];
		for (int i = 0; i < intArray.length; i++) {
			charArray[i] = (char) intArray[i];
		}
		System.out.println("charArray"+Arrays.toString(charArray));
		
		//desc order
		for (int i = 0; i < intArray.length; i++) {
			
			for (int j = i+1; j < intArray.length; j++) {
				if(intArray[i] < intArray[j])
				{
					int n1 = intArray[i];
					intArray[i] = intArray[j];
					intArray[j] = n1;
				}
			}
			
		}
		
		System.out.println(Arrays.toString(intArray));
		
		//string to ascii and print charator whose ascii value is prime
		
		String str = "abABcdCD";
		StringBuffer strBuffer= new StringBuffer();
		try {
			byte[] bytes = str.getBytes("US-ASCII");
			System.out.println(Arrays.toString(bytes));
			
			for (int i = 0; i < bytes.length; i++) {
				if(bytes[i]%2 == 0)
				{
					strBuffer.append(bytes[i]+",");
				}
			}
			
			System.out.println(strBuffer.toString());
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
