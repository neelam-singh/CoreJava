package neelam.singh;

public class ClassC extends ClassB{
	ClassC(){
		System.out.println("C");
	}
	
	public static void main(String args[])
	{
		ClassC Obj = new ClassC();
	}

}
