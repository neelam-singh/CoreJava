package neelam.singh;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class Test1 {

	public static void main(String[] args) {

			Map<Integer, Employee> testMap = new HashMap<>();
			testMap.put(1, new Employee(1, "emp1", 20000.00));
			testMap.put(2, new Employee(1, "emp2", 10000.00));
			testMap.put(3, new Employee(1, "emp3", 60000.00));
			testMap.put(4, new Employee(1, "emp4", 20500.00));
			testMap.put(5, new Employee(1, "emp5", 2000.00));
			
			testMap.forEach((K,V)->{
				System.out.println("Key: "+K+" emp value: "+V.empID+","+V.empName+","+V.empSal);
			});
			
			testMap = testMap.entrySet().stream()
					.sorted(Map.Entry.comparingByKey())
	                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
	                        (oldValue, newValue) -> oldValue, LinkedHashMap::new));

	       // collect.forEach((k, v) -> System.out.println(k + ":" + v));
	}

}
