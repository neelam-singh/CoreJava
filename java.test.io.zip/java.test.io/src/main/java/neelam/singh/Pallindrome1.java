package neelam.singh;

import java.util.Arrays;

public class Pallindrome1 {
	
	static int MAX = 256;

	public static void main(String[] args) {
		//chk given input is palindrome or not
		
		String original= "454";
		String reverse = "";
		for (int i = original.length()-1; i >= 0; i--) {
			reverse = reverse + original.charAt(i);
		}
		System.out.println(reverse);
		if(original.equals(reverse))
		{
			System.out.println("String is palindrome");
		}
		else
		{
			System.out.println("String not a palindrome");
		}
		
		
		//check if gvn string has a reversible equal substring at end
		
		String input = "abctqrcba";
		String substring = "";
		
		int i = 0;
		int j = input.length()-1;
		
		while(j>=0)
		{
			if(input.charAt(i)== input.charAt(j))
			{
				substring = substring+input.charAt(i);
				i++;
				j--;
			}
			else
			{
				break;
			}
		}
		
		System.out.println(substring);
		
		//Check if rearranging Array elements can form a Palindrome or not
		
		int []arr = {1, 2, 3, 4, 1};//{1, 2, 3, 1, 2}
	    int n = arr.length;
	    if(can_form_palindrome(arr, n))
	      System.out.println("YES");
	    else
	      System.out.println("NO");
		

	}
	
	static boolean can_form_palindrome(int []arr, int n)
	  {
	 
	    // create an empty string
	    // to append elements of an array
	    String str = "";
	 
	    // append each element to the string str to form
	    // a string so that we can solve it in easy way
	    for (int i = 0; i < n; i++) {
	      str += arr[i];
	    }
	 
	    // Create a freq array and initialize all
	    // values as 0
	    int freq[] = new int[MAX];
	    Arrays.fill(freq,0);
	 
	    // For each character in formed string,
	    // increment freq in the corresponding
	    // freq array
	    for (int i1 = 0; i1<str.length(); i1++) {
	      freq[str.charAt(i1)]++;
	    }
	    int count = 0;
	 
	    // Count odd occurring characters
	    for (int i1 = 0; i1 < MAX; i1++) {
	      if ((freq[i1] & 1)!=0) {
	        count++;
	      }
	      if (count > 1) {
	        return false;
	      }
	    }
	 
	    // Return true if odd count is 0 or 1,
	    return true;
	  }
	
	

}
