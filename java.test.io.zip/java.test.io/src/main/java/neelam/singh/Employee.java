package neelam.singh;

public class Employee {
	
	Integer empID;
	String empName;
	Double empSal;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(Integer empID, String empName, Double empSal) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.empSal = empSal;
	}
	public Integer getEmpID() {
		return empID;
	}
	public void setEmpID(Integer empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(Double empSal) {
		this.empSal = empSal;
	}
	
	

}
