package neelam.singh;

public class FactorialNumber {

	public static void main(String[] args) {
		int n = 5;
		int fact = fact(n);
		System.out.println("factorial:"+fact);
	}

	private static int fact(int n) {
		int fact = 1;
		while(n>0)
		{
			fact = fact*n;
			n--;
		}
		
		return fact;
	}

}
