package neelam.singh;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class NiceTest {

	public static void main(String[] args) {

		List<Integer> inputList = new ArrayList<>();

	}

	public int[] getTimeseqInput(int[] inputListArr) {
		Arrays.sort(inputListArr);
		for (int i = 0; i < inputListArr.length; i++) {
			System.out.println(inputListArr[i]);
		}

		return inputListArr;
	}

}
