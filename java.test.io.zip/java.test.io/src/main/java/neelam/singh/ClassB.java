package neelam.singh;

public class ClassB extends ClassA {
	
	ClassB(){
		System.out.println("B");
	}

}
