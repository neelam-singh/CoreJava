package neelam.singh;

public class SingleTonPattern {
	
	/*
	 * private static SingleTonPattern instanceObj = new SingleTonPattern(); private
	 * SingleTonPattern() {
	 * 
	 * }
	 * 
	 * public SingleTonPattern getInstance() { return instanceObj; }
	 */

	private static SingleTonPattern instanceObj;
	private SingleTonPattern() {
		
	}
	
	public SingleTonPattern getInstance() {
		if (instanceObj == null)
	    {
	      // if instance is null, initialize
			instanceObj = new SingleTonPattern();
	    }
	    return instanceObj;
	  }

}
